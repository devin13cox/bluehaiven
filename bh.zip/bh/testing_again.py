import tkinter as tk


def writefile():
    with open("./name.txt", "r+") as f:
        f.truncate(0)
        f.writelines(name.get())
        print("File has been written !")
        root.update()

root = tk.Tk()

canvas = tk.Canvas(root, width = 800, height = 600)
canvas.pack()

frame = tk.Frame(root, bg = "yellow")
frame.place(relwidth = 1, relheight = 1)
frame.pack()

name = tk.StringVar()
name.trace("w", lambda l, idx, mode: writefile())
entry = tk.Entry(frame, textvariable = name, bg = "orange", font= "arial 18 ", justify = "center", fg = "black")
entry.place(relx = 0.25, rely = 0.05, relwidth = 0.5, relheight = 0.1)
entry.focus_set()
entry.pack()

root.mainloop()