
###FOR SPREADSHEET.py
if p.status == 'GOOD':
    select = random.randint(1, 1001)
    if select < 996:
        return random.randint(40,100)
    elif select < 998:
        return random.randint(100, 150)
    elif select < 1000:
        return random.randint(150,300)
    else:
        return random.randint(0,40)
elif p.status == 'WARNING':
    select = random.randint(1, 1001)
    if select < 700:
        return random.randint(100,150)
    elif select < 750:
        return random.randint(150, 300)
    elif select < 800:
        return random.randint(0,40)
    else:
        return random.randint(40,100)
else:
    select = random.randint(1, 1001)
    if select < 500:
        return random.randint(150,300)
    elif select < 550:
        return random.randint(0, 40)
    elif select < 800:
        return random.randint(100,150)
    else:
        return random.randint(40,100)